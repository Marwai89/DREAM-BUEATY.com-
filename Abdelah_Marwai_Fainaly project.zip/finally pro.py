# Import Module
from tkinter import *
from webbrowser import *

# creating a root window
root = Tk()

# mention the root window title and dimension
root.title("DREAM BUEATY ")
# Set geometry(widthxheight)
root.geometry('400x300')

# add a label to the root window
lbl = Label(root, text = " DREAM BUEATY ")
lbl.grid()

# function to display text when button will be clicked
def clicked():
 lbl.configure(text = "Welcome to DREAM BUEATY ")

# button widget with black color text inside
btn1 = Button(root, text = "makeup" , bg="orange", fg = "black", command=clicked)

# set Button btn1 grid
btn1.grid(column=1, row=2)

# button widget with red color text inside
btn2 = Button(root, text = "skin care" , bg="light pink",fg = "black", command=clicked)

# set Button btn2 grid
btn2.grid(column=2, row=2)

# Execute Tkinter
root.mainloop()

